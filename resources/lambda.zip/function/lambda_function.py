import time
import json
import boto3
from populartimes import get_id
    

def lambda_handler(event, context): 
    data = get_id("AIzaSyCS_R7l9xg6mwEqnMCftSs36QXVsKPMUiM", "ChIJQwRohxBbwokRmHrfAMb3ixc")
    
    # Get current time 
    t = time.localtime()
    timestamp = time.strftime('%m%d%Y_%H%M', t)
    print(timestamp)
    
    # Export the data to S3
    client = boto3.client('s3')
    response = client.put_object(Bucket='pop-time-data', Body=json.dumps(data), Key=f'Data/{timestamp}.json')
    print('saved')
    